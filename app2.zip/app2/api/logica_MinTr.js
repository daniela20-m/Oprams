const puppeteer = require('puppeteer')

module.exports = class logica_MinTr{
    // Web Scraping sobre el módulo 1 MinTransporte
        async runModulo1(placa){ // Función asíncrona recibiendo parámetro placa

        const browser = await puppeteer.launch( {headless: true, args: ['--start-maximized'] }); // Ejecutar navegador
        const page = await browser.newPage() // Abrir nueva pagina
        await page.setViewport({ width: 1920, height: 1080}); // Establecer resolución de pantalla
        
        await page.goto('https://normalizacion.mintransporte.gov.co/'); //Navegar hacia la página
        await page.screenshot({path: '../web/evidencia/mintransporte/foto1.jpg'}); // Screenshot

        await page.type('#id_placa', placa) // Ingresar placa en input
        await page.screenshot({path: '../web/evidencia/mintransporte/foto2.jpg'}); // Screenshot

        const buscarPlaca = await page.waitForXPath('/html/body/div[1]/div/form/button') // Esperar que encuentre el botón buscar sobre el xpath
        buscarPlaca.click(); // Hacer click al botón
        await page.screenshot({path: '../web/evidencia/mintransporte/foto3.jpg'}); // Screenshot
    
        const element = await page.waitForSelector('body > div.alert.alert-success'); // Esperar que encuentre selector el cual es la respuesta sobre la consulta
        const valueAux = await element.evaluate(el => el.textContent); // Evaluar y recuperar el contenido del elemento en la variable Value
        const value = valueAux.trim();
        
        await page.screenshot({path: '../web/evidencia/mintransporte/foto4.jpg'}); // Screenshot

        await browser.close(); // Cerrar navegador
        return value; // Retornar respuesta
    }
}