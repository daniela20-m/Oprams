/* importar módulos express, puppeteer y cors */
const express = require('express')
const puppeteer = require('puppeteer')
const cors = require('cors')
const logica_MinTr = require('./logica_MinTr.js')
const logica_Simit = require('./logica_Simit.js')
const logica_Ruaf = require('./logica_Ruaf.js')

// Definir parámetros del servidor
const app = express()
const port = 3000
let respuestaTransaccion = 'false'; // Variable string para enviar mensaje al front-end si una transacción se efectuó [true o false]

let resultadoArr = []; // Variable array resultado de todas las consultas de las paginas

app.use(
    express.urlencoded({
        extended: true
    })
)
app.use(
    express.json({
        type: "*/*"
    })
)

app.use(cors());

// Función tipo get para enviar una respuesta sobre la url del servidor /transaction

app.get('/transaction', (req, res) => {
    console.log("Res server: "+respuestaTransaccion)
    if (respuestaTransaccion === 'true') { // Si se efectuó todas las consultas(web scraping)
        console.log(resultadoArr)
        let resultadoMT = resultadoArr[resultadoArr.length - 3] // Obtener resultado MinTransporte, elemento del array resultadoArr
        let resultadoSM = resultadoArr[resultadoArr.length - 2] // Obtener resultado Simit, elemento del array resultadoArr
        let resultadoRF = resultadoArr[resultadoArr.length - 1] // Obtener resultado Ruaf, elemento del array resultadoArr
        let mt = resultadoMT.replace(/\n/g, ''); // Reemplazar los saltos de línea resultadoMT por ''
        let transactionResult = {resultConsultaMT: mt, resultConsultaSM: resultadoSM, resultConsultaRF: resultadoRF, validarTransaccion: 'true'}
        res.send(JSON.stringify(transactionResult)); // Convertir ese elemento en Json String para enviarlo    
    } else {
        res.send(JSON.stringify({validarTransaccion: 'false'})) // String transacción NO efectuada
    }
})

// Función asíncrona de la librería express, empleando metodo Post para recibir parámetros y enviar respuesta sobre la url del servidor /transaction
app.post('/transaction', async (req, res) => {
    resultadoArr = [];
    respuestaTransaccion = 'false';
    // Definir array JSON de entrada
    var transactionStr = JSON.stringify(req.body); // Obtener el cuerpo del array json String
    var transactionObj = JSON.parse(transactionStr); // Convertir el array de Json string a Json object
    var opcionModulo = 0;
    var placa = transactionObj["transactionPlaca"]; // Obtener la placa del objeto JSON
    var tipoDoc = transactionObj["transactionTipoDoc"]; // Obtener tipoDoc del objeto JSON
    var numDoc = transactionObj["transactionNumDoc"] // Obtener numDoc del objeto JSON
    var fechaExp = transactionObj["transactionFechaExp"] // Obtener fechaExp del objeto JSON
     console.log("Datos que llegaron al server: "+placa+" "+tipoDoc+" "+numDoc+" "+" "+fechaExp)

    do {
        opcionModulo++;
        console.log("Modulo: "+opcionModulo);
    switch (opcionModulo) {
        case 1: // Si el módulo es 1: Pagina MinTransporte
             await runMinTransporte(placa);   
            break;
        case 2: // Si el módulo es 2: Pagina Simit
             await runSimit(placa);             
            break;
        case 3:
            await runRuaf(tipoDoc, numDoc, fechaExp);
            break;
        default:
            break;
    }
} while (opcionModulo !== 3);

    // Obtener los resultados del array global y llenarlos en variables distintas para crear un objeto json string
    let resultadoA = resultadoArr[resultadoArr.length - 3]
    let resultadoB = resultadoArr[resultadoArr.length - 2]
    let resultadoC = resultadoArr[resultadoArr.length - 1]
    if (res.send(JSON.stringify(resultadoA, resultadoB, resultadoC))){
      respuestaTransaccion = 'true'; // string transacción efectuada
    }
})

// Función para iniciar servidor
app.listen(port, () => {
    console.log(`Estoy ejecutandome en http://localhost:${port}`)
})

/* Función asíncrona para instanciar el objeto de la lógica web scraping y esperar a que se haga el proceso para retornar un resultado*/
async function runMinTransporte(placa){
    let minTrObj = new logica_MinTr();
    const datos = await minTrObj.runModulo1(placa);
    console.log("Resultado MinTransporte: \n"+datos)
    resultadoArr.push(datos)
    console.log("Se finalizo el proceso A")
}

/* Función asíncrona para instanciar el objeto de la lógica web scraping y esperar a que se haga el proceso para retornar un resultado*/
async function runSimit(placa){
    let simitObj = new logica_Simit();
    const datos = await simitObj.runModulo2(placa);
    console.log("Resultado Simit: \n"+datos.datosTbody)
    resultadoArr.push(datos)
    console.log("Se finalizo el proceso B")
}

/* Función asíncrona para instanciar el objeto de la lógica web scraping y esperar a que se haga el proceso para retornar un resultado*/
async function runRuaf(tipoDoc, numDoc, fechaExp){
    let ruafObj = new logica_Ruaf();
    const datos = await ruafObj.runModulo3(tipoDoc, numDoc, fechaExp);
    console.log("Resultado Ruaf: \n"+datos)
    resultadoArr.push(datos)
    console.log("Se finalizo el proceso C")
}