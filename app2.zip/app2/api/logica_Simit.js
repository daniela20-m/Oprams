const puppeteer = require("puppeteer");

module.exports = class logica_Simit {
  async runModulo2(placa) {
    const browser = await puppeteer.launch({
      headless: true,
      args: ["--start-maximized"],
    }); // Ejecutar navegador
    const page = await browser.newPage(); // Abrir nueva pagina
    await page.setViewport({ width: 1920, height: 1080 }); // Establecer resolución de pantalla

    await page.goto("https://www.fcm.org.co/simit/#/estado-cuenta?numDocPlacaProp=" + placa); //Navegar hacia la página, se concatena los parámetros de entrada directamente
    await page.screenshot({ path: "../web/evidencia/simit/foto1.jpg" }); // Screenshot

    /*Proceso para cerrar la primera ventana modal, se obtiene el selector del párrafo(texto) del modal más no el modal en si
        Finalidad: -Al aparecer una ventana modal de verificacion de información, no se sabe cuánto tiempo tarda en desaparecer
                    por consiguiente hay que estar "preguntando" mediante un ciclo repetitivo si esa ventana aun es visible, el ciclo
                    deja de repetirse cuando la ventana NO es visible.

        ¿Qué se valida?: No se toma el xpath o selector de la ventana modal sino de un párrafo de texto que lo contiene, ya que fué más
        sencillo validar el tamaño de fuente, es decir, si el ancho y alto del párrafo es mayor a cero quiere decir que aún está visible
        la ventana modal con su contenido, en caso de su longitud sea cero, significa que ya está oculta la ventana, lo que indica que
        puede seguir con el flujo normal. (Hasta que no se desaparesca esa ventana no seguirá validando lo demás).
      */
    let cont = 0;
    let boxModel;
    let parrafo;
    // Se obtiene el párrafo del texto mediante selector
    try {
      parrafo = await page.waitForSelector("#whcModal > div > div > div > p.font-weight-bold.mb-0.fs-17",{ timeout: 45000 }); // Esperar que encuentre selector de la ventana modal
    } catch (error) {
      console.log("No se encontro selector " + error);
    }
    try {
      if (parrafo) {
        console.log(parrafo + " existe");
        await page.waitForTimeout(1000);
        do {
          // Se vuelve a obtener el selector del párrafo en caso de que se encuentre la primer vez en la página.
          // ¿Para qué?: Se debe obtener cada vez que se hace un ciclo ya que va "preguntando" el "estado" del párrafo todo el tiempo el cual sirve para validar su longitud.
          parrafo = await page.waitForSelector("#whcModal > div > div > div > p.font-weight-bold.mb-0.fs-17",{ timeout: 15000 }); // Esperar que encuentre selector de la ventana modal
          boxModel = await parrafo.boxModel();
          if (boxModel && boxModel.width > 0 && boxModel.height > 0) {
            // Validar el tamaño del párrafo de la ventana modal width(ancho) y height(alto)
            cont++;
            await page.waitForTimeout(1000);
            console.log("El elemento <p> es visible, Tiempo transcurrido: " +cont +" segundos.");
          } else {
            console.log("El elemento <p> no es visible");
          }
        } while (boxModel && boxModel.width > 0 && boxModel.height > 0); // El ciclo se repite siempre y cuando el ancho y alto de la ventana sea mayor a cero(visible)
      } else {
        console.log("No existe parrafo"); // A veces no aparece la ventana al consultar algo por lo tanto no la sigue buscando sino que sigue el flujo normal
      }
    } catch (error) {
      console.log("No existe parrafo " + error.message);
    }

    /*Proceso para cerrar la pantalla de carga al momento de consultar
        Finalidad: - Cuando ya NO es visible el primer modal, sigue una pantalla de carga el cual no sabemos cuánto tiempo tarda en desaparecer, por lo tanto hay que realizar
                     un proceso similar al anterior.

        ¿Qué se valida?: Se toma el selector de la pantalla de carga y se hace la validación cuando la propiedad "display" es none.
        NOTA: Esa validación realmente sobra ya que al momento que aparece la pantalla de carga(loader) no se puede tomar ningún xpath o selector por lo tanto no se puede
        validar algún componente.

        ¿Entonces cóno funciona?: Realmente la única línea válida es la 68 en donde se declara la variable loader y se pone un timeout de 2 minutos(120000 ms), tiempo suficiente para
        que aparezca la pantalla de carga, esta se puede detectar segundos antes de que va a finalizar la carga, cuando ya sale un resultado de la consulta se detecta y se
        desaparece, al detectarse entra al ciclo do-while, pero como su estado display es "none" se sale del ciclo rápidamente y sigue el flujo normal.

        En un futuro se quita código desde la línea 74 hasta la 102, por ahora dejarlo así.
      */
    cont = 0;
    let loader = await page.waitForSelector("#loader", { timeout: 120000 });
    let displayValue = null;
    try {
      if (loader) {
        console.log("#loader existe");
        await page.waitForTimeout(1000);
        do {
          loader = await page.waitForSelector("#loader", { timeout: 60000 });
          const modalLoader = await page.waitForSelector("#loader"); // Esperar que encuentre selector de la ventana modal
          displayValue = await page.evaluate((modalLoader) => {
            // Evaluar element
            const style = getComputedStyle(modalLoader); // Obtener estilos del element
            return style.display; // Retornar propiedad display
          }, modalLoader);
          // Verifica si la propiedad 'display' es igual a 'none'
          console.log("propiedad: " + displayValue);
          if (displayValue === "none") {
            cont++;
            console.log("El elemento tiene la propiedad display:none");
            await page.waitForTimeout(1000);
            console.log("El elemento #loader es visible, Tiempo transcurrido: " + cont +" segundos.");
          } else {
            console.log("El elemento #loader no es visible");
          }
        } while (displayValue !== "none");
      } else {
        console.log("No existe loader");
      }
    } catch (error) {
      console.log("No existe loader " + error.message);
    }

    /* Inicia la validación de los resultados obtenidos de la consulta 
       Recordar que existen 2 escenarios, cuando la placa tiene comparendos o cuando no los tiene.
       En ambos casos se toma el xpath o selector de ambos resultados y se evalúa el elemento (element.evaluate)

       Análisis para el resultado: -Si la variable resultado existe en el escenario 1, quiere decir que en el escenario 2 NO existe
                                   -Si la variable resultado existe en el escenario 2, quiere decir que en el escenario 1 NO existe

       Tener en cuenta que la variable resultado es el xpath o selector según el posible resultado que arroje la página.
    */
    await page.waitForTimeout(1000);

    // Escenario 1: cuando NO hay comparendos
    let value = null;
    try {
      const element = await page.waitForXPath('//h3[contains(text(), "No tienes comparendos")]',{ timeout: 5000 }); // Cambia el selector al del elemento que deseas verificar
      if (element) {
        console.log("Elemento A existe en la página.");
        value = await element.evaluate((el) => el.textContent);
      }
    } catch (error) {
      console.log("Elemento A NO existe en la página.");
    }

    // Escenario 2: cuando SI hay comparendos
    try {
      const element = await page.waitForSelector("#resumenEstadoCuenta > div", {timeout: 5000,}); // Esperar que encuentre selector el cual es la respuesta sobre la consulta
      if (element) {
        console.log("Elemento B existe en la página.");

        // Extraer informacion DIV estado general multas y comparendos
        let resultadoDiv = await element.evaluate((el) => el.textContent); // Evaluar y recuperar el contenido del elemento en la variable Value
        let resultadoDivtext = resultadoDiv.trim();

        // Extraer información de tabla
        const tableXPath = '//*[@id="multaTable"]';
        const tableData = await page.$x(tableXPath);

        if (tableData.length > 0) {
          const filas = await page.$x(`${tableXPath}//tr`);
          const datosTabla = [];

          // Recorrer las filas de la tabla
          for (let fila of filas) {
            const columnas = await fila.$$("td");
            const datosFila = [];
            // Recorrer las columnas de la tabla
            for (const columna of columnas) {
              const texto = await columna.evaluate((node) => node.textContent);
              datosFila.push(texto.trim());
            }
            datosTabla.push(datosFila);
          }
          value = { datosTbody: datosTabla, datosDiv: resultadoDivtext };
        }
      }
    } catch (error) {
      console.log("Elemento B NO existe en la página.");
    }

    await page.screenshot({ path: "../web/evidencia/simit/foto4.jpg" }); // Screenshot

    await browser.close(); // Cerrar navegador
    return value; // Retornar respuesta
  }
};