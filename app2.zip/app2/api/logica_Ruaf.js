const puppeteer = require('puppeteer');

let page;

module.exports = class logica_Simit{
  
    async runModulo3(tipoDoc, numDoc, fechaExp){

    const browser = await puppeteer.launch({ 
        headless: true,
        args: ['--start-maximized',
              '--no-sandbox',
              '--disable-setuid-sandbox',
              '--disable-infobars',
              '--window-position=0,0',
              '--ignore-certifcate-errors ',
              '--ignore-certifcate-errors-spki-list',
              '--user-agent="Mozilla/5.0 (Macintosh; Intel Mac OS X 10_12_6) AppleWebKit/537.36 (KHTML, como Gecko) Chrome/65.0.3312.0 Safari/537.36"']
      });

    page = await browser.newPage() // Abrir nueva pagina
    await page.setViewport({ width: 1920, height: 1080 }); // Establecer resolución de pantalla

    await page.goto('https://ruaf.sispro.gov.co/TerminosCondiciones.aspx');
    await page.screenshot({ path: '../web/evidencia/ruaf/foto1.jpg' }); // Screenshot

  
  const xpathx = '//*[@id="MainContent_RadioButtonList1_0"]';
  const elementosx = await page.$x(xpathx);
  
  if (elementosx.length > 0) {
    console.log(`El selector XPath ${xpathx} existe en la página.`);
    // Realiza las acciones que necesitas con el elemento encontrado
  } else {
    console.log(`El selector XPath ${xpathx} no existe en la página.`);
  }

    const aceptarTerminos = await page.waitForXPath('//*[@id="MainContent_RadioButtonList1_0"]', { timeout: 10000 }); // Esperar que encuentre radio button mediante xpath
    aceptarTerminos.click(); // Hacer click al radio button

    const currentUrl = await page.url();
    console.log('URL actual:', currentUrl);
    await page.waitForTimeout(2000);
    await page.screenshot({ path: '../web/evidencia/ruaf/foto3.jpg' }); // Screenshot
    console.log("finnnn")

    const enviarTerminos = await page.waitForXPath('//*[@id="MainContent_btnEnviar"]'); // Esperar que encuentre xpath de botón aceptar terminos y condiciones
    enviarTerminos.click(); // hacer click al botón
    await page.waitForTimeout(15000); 
    const currentUrl2 = await page.url();
    console.log('URL actual:', currentUrl2);
    
    //await page.waitForSelector('#ddlTiposDocumentos'); 
    const xpath = '//*[@id="ddlTiposDocumentos"]';
    const elementos = await page.$x(xpath);
    await page.waitForXPath(xpath);
    
    if (elementos.length > 0) {
      console.log(`El selector XPath ${xpath} existe en la página.`);
      // Realiza las acciones que necesitas con el elemento encontrado
    } else {
      console.log(`El selector XPath ${xpath} no existe en la página.`);
    }
    await page.select('#ddlTiposDocumentos:nth-child(1)', tipoDoc); // Ingresar el tipo de documento a consultar en el Select
    await page.screenshot({ path: '../web/evidencia/ruaf/foto4.jpg' }); // Screenshot
    await page.waitForTimeout(2000); // Timeout de x segundos

    await page.type('#MainContent_txbNumeroIdentificacion:nth-child(1)', numDoc) // Ingresar numero de identificación     52693093 / 15/10/1997
    await page.screenshot({ path: '../web/evidencia/ruaf/foto5.jpg' }); // Screenshot
    await page.waitForTimeout(2000); // Timeout de x segundos

    await page.type('#MainContent_datepicker:nth-child(1)', fechaExp) // Ingresar fecha a consultar en calendar
    await page.screenshot({ path: '../web/evidencia/ruaf/foto6.jpg' }); // Screenshot

    const enterKey = '\u000d'; // Definir tecla Enter
    await page.keyboard.press(enterKey); // Presionar tecla enter para cerrar calendar
    await page.waitForTimeout(2000); // Timeout de x segundos

    const consultar = await page.waitForXPath('//*[@id="MainContent_btnConsultar"]'); // Esperar que encuentre xpath para botón consultar
    consultar.click(); // hacer click al botón
    await page.screenshot({ path: '../web/evidencia/ruaf/foto7.jpg' }); // Screenshot
    await page.waitForTimeout(3000); // Timeout de x segundos
    await page.screenshot({ path: '../web/evidencia/ruaf/foto8.jpg' }); // Screenshot
    /*Verificar si la información ingresada a existe o no después de hacer click en consultar.
     1. Para hacer la validación se busca la ventana modal que muestra un error al encontrar documento, por defecto la ventana modal estará oculta.
     2. Si la ventana modal tiene la propiedad css "display:none" quiere decir que los datos ingresados si son válidos, de lo contrario los datos ingresados son erróneos.
     */
    let displayValue;
    let value = null;
    let existeDoc = false;
    try {
        const element = await page.waitForSelector('#dialog-confirm-Mensaje-NoExiste', { timeout: 10000 }); // Cambia el selector al del elemento que deseas verificar
        displayValue = await page.evaluate(element => { // Evaluar element
            const style = getComputedStyle(element); // Obtener estilos del element
            return style.display; // Retornar propiedad display
        }, element);
        console.log("El display es: " + displayValue);
        if (displayValue !== 'none') {
            console.log('Elemento A existe en la página.');
            await page.screenshot({ path: '../web/evidencia/ruaf/foto9.jpg' }); // Screenshot
            let valueAux = await element.evaluate(el => el.textContent);
            value = valueAux.trim();

        }
        else {
            existeDoc = true;
        }
    } catch (error) {
        existeDoc = true;
        console.log('Elemento A NO existe en la página.');
    }
    let carga;
    if (existeDoc) {
        try {
        carga = await page.waitForXPath('//div[text()="INFORMACIÓN BASICA"]', { timeout: 45000 });
        }catch (error) {
            value = "Los datos ingresados pueden estar incorrectos, por favor intente realizar nuevamente la consulta o verifique la información. \n Error: "+error;
        }
        if (carga) {
            console.log('Elemento de consulta existe en la página.');
            await page.screenshot({ path: '../web/evidencia/ruaf/foto9.jpg' }); // Screenshot
            // ================================= Extraer datos de consulta de Tbody en la web====================================

            const tableXPath = '//div[@aria-label="Texto de informes"]/following::tbody[position() < last() - 1]'; // Crear xpath referenciando la tabla
            const tableData = await page.$x(tableXPath); // Consultar el xpath

            if (tableData.length > 0) {
                const filas = await page.$x(`${tableXPath}//tr`);  // Obtener las filas de la tabla
                const datosTabla = [];  // Inicializar un arreglo para almacenar los datos de la tabla

                // Recorrer las filas de la tabla
                for (let fila of filas) {
                    const columnas = await fila.$$('td');
                    const datosFila = [];

                    // Recorrer las columnas de la fila
                    for (let columna of columnas) {
                        const texto = await columna.evaluate(node => node.textContent);
                        datosFila.push(texto.trim());
                    }
                    datosTabla.push(datosFila); // Agregar los datos de las filas y columnas al arreglo principal
                }

                // ================================= buscar y borrar índices en donde existan espacios en blanco ====================================
                let esVacio = 0;
                let borrarIndices = [];
                let indice = 0;
                // Iterar la información de datos de la tabla y validar si cada elemento está vacío
                for (let i = 0; i < datosTabla.length; i++) {
                    const element = datosTabla[i];
                    for (let j = 0; j < element.length; j++) {
                        const x = element[j];
                        //console.log('Elemento a evaluar: '+x)
                        if (x == ('')) {
                            esVacio++;
                        }
                    }
                    if (esVacio == datosTabla[i].length) { // Si en un índice todos los elementos están vacíos, se crea otro array para almacenar los índices a borrar
                       // console.log('borrar Indice: '+i);
                        borrarIndices[indice] = i;
                        indice++;
                    }
                    esVacio = 0;
                }
                
                let arrTbody = [].concat(datosTabla);

                console.log('Nuevo array: '+arrTbody.length)
                //contIndices = 0;
                //console.log('Los indices a borrar son: '+borrarIndices);

                borrarIndices.sort((a, b) => b - a);

                // Eliminar los índices
                for (let i of borrarIndices) {
                    arrTbody.splice(i, 1);
                }

                // ================================= Extraer datos de consulta de DIV en la web====================================
                const arrDiv = [];
                const datosDivXpath = '//div[contains(text(), "No se han reportado")]/ancestor-or-self::tbody/tr[2]/td/table/tbody/tr/td/table/tbody/tr/td[3]/div/div';
                const datosDivData = await page.$x(datosDivXpath);

                for (let datos of datosDivData) {
                    const texto = await datos.evaluate(node => node.textContent);
                    arrDiv.push(texto.trim());
                }
                // Eliminar texto sobrante de divs
                for (let i = arrDiv.length - 1; i >= 0; i--) {
                    if (arrDiv[i].includes('Fecha de Corte:') || arrDiv[i].includes('2023') || arrDiv[i].includes('2024') || arrDiv[i].includes('2025')) {
                        arrDiv.splice(i, 1);
                    }
                }
                const ordenarArr = ordenarDatos(arrTbody, arrDiv);
                console.log("Datos ordenados: \n\n")
                console.log(ordenarArr)
                value = { datosTbody: ordenarArr[0], datosDiv: ordenarArr[1] }
                console.log(value)
            } else {
                console.log("Tiempo agotado")
            }
        }
    }
    await page.screenshot({ path: '../web/evidencia/ruaf/foto9.jpg' }); // Screenshot
    await browser.close(); // Cerrar navegador
    return value;
    }
}

function ordenarDatos(datosTabla, datosDiv) {

    let T_InfoBasica = "INFORMACIÓN BASICA";
    let T_AfiliacionSalud = "AFILIACIÓN A SALUD";
    let T_AfiliacionPensiones = "AFILIACIÓN A PENSIONES";
    let T_AfiliacionRiesgosLab = "AFILIACIÓN A RIESGOS LABORALES";
    let T_AfiliacionCompFam = "AFILIACIÓN A COMPENSACIÓN FAMILIAR";
    let T_AfiliacionCesantias = "AFILIACIÓN A CESANTIAS";
    let T_Pensionados = "PENSIONADOS";
    let T_VinculacionProgAS = "INFORMACIÓN VINCULACIÓN A PROGRAMAS DE ASISTENCIA SOCIAL";

    // Organizar titulos de divs
    let titulosDiv = [];

    for (let i = 0; i < datosDiv.length; i++) {
        if (datosDiv[i].includes('No se han reportado')) {
            titulosDiv.push(datosDiv[i - 1], datosDiv[i])
        }
    }

    // Organizar titulos datos tabla
    let titulosTabla = [].concat(datosTabla);

    let itemAñadidos = 0; 
    for (let i = 0; i < datosTabla.length; i++) {
        if (datosTabla[i].includes('Número de Identificación')) {
            titulosTabla.splice(i+itemAñadidos, 0, T_InfoBasica)
            itemAñadidos++;
        }
        else if (datosTabla[i].includes('Departamento -> Municipio')) {
            titulosTabla.splice(i+itemAñadidos, 0, T_AfiliacionSalud)
            itemAñadidos++;
        }
        else if (datosTabla[i][0].includes('Régimen') && datosTabla[i].length == 4) {
            titulosTabla.splice(i+itemAñadidos, 0, T_AfiliacionPensiones)
            itemAñadidos++;
        }
        else if (datosTabla[i].includes('Actividad Economica') && datosTabla[i].length == 5) {
            titulosTabla.splice(i+itemAñadidos, 0, T_AfiliacionRiesgosLab)
            itemAñadidos++;
        }
        else if (datosTabla[i].includes('Tipo de Miembro de la Población Cubierta')) {
            titulosTabla.splice(i+itemAñadidos, 0, T_AfiliacionCompFam)
            itemAñadidos++;
        }
        else if (datosTabla[i][0].includes('Régimen') && datosTabla[i].length == 5) {
            titulosTabla.splice(i+itemAñadidos, 0, T_AfiliacionCesantias)
            itemAñadidos++;
        }
          else if (datosTabla[i][0].includes('Entidad Pagadora de pensión')) {
            titulosTabla.splice(i+itemAñadidos, 0, T_Pensionados)
            itemAñadidos++;
        }
      }

    return [titulosTabla, titulosDiv];
}