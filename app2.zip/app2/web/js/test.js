let datos= {
    datosTbody: [
      'INFORMACIÓN BASICA',
      [
        'Número de Identificación',
        'Primer Nombre',
        'Segundo Nombre',
        'Primer Apellido',
        'Segundo Apellido',
        'Sexo'
      ],
      [ 'CC 1016109429', 'JUAN', 'SEBASTIAN', 'JARAMILLO', 'SILVA', 'M' ],
      'AFILIACIÓN A SALUD',
      [
        'Administradora',
        'Régimen',
        'Fecha Afiliacion',
        'Estado de Afiliación',
        'Tipo de Afiliado',
        'Departamento -> Municipio'
      ],
      [
        'EPS FAMISANAR S.A.S.',
        'Contributivo',
        '01/03/2018',
        'Activo',
        'COTIZANTE',
        'BOGOTA D.C.'
      ],
      'AFILIACIÓN A PENSIONES',
      [
        'Régimen',
        'Administradora',
        'Fecha de Afiliación',
        'Estado de Afiliación'
      ],
      [
        'PENSIONES: AHORRO INDIVIDUAL',
        'SOCIEDAD ADMINISTRADORA DE FONDOS DE PENSIONES Y CESANTIAS PORVENIR SA',
        '2023-02-12',
        'Inactivo'
      ],
      [
        'PENSIONES: AHORRO INDIVIDUAL',
        'SOCIEDAD ADMINISTRADORA DE FONDOS DE PENSIONES Y CESANTIAS PORVENIR SA',
        '2023-02-11',
        'Activo'
      ],
      'AFILIACIÓN A COMPENSACIÓN FAMILIAR',
      [
        'Administradora CF',
        'Fecha de Afiliación',
        'Estado de Afiliación',
        'Tipo de Miembro de la Población Cubierta',
        'Tipo de Afiliado',
        'Municipio Labora'
      ],
      [
        'CAJA DE COMPENSACION FAMILIAR COMPENSAR',
        '2023-02-11',
        'Activo',
        'Afiliado',
        'Trabajador afiliado dependiente',
        ''
      ]
    ],
    datosDiv: [
      'AFILIACIÓN A RIESGOS LABORALES',
      'No se han reportado afiliaciones para esta persona',
      'AFILIACIÓN A CESANTIAS',
      'No se han reportado afiliaciones para esta persona',
      'PENSIONADOS',
      'No se han reportado pensiones para esta persona.',
      'VINCULACIÓN A PROGRAMAS DE  ASISTENCIA SOCIAL',
      'No se han reportado vinculaciones para esta persona.'
    ]
  }

let arrTitulo = [];
let arrHeader = [];
let arrBody = [];
let auxArrBody = [];
let tipoDato;
var datosTbody = datos.datosTbody;

for (let i = 0; i < datosTbody.length;i++) {
    if (typeof datosTbody[i] === "string") {
        console.log(datosTbody[i] + " Es Titulo");
        arrTitulo.push(datosTbody[i]);
        if (i !== 0){
            arrBody.push(auxArrBody)
            auxArrBody = [];
        }
    }else
    if (i !== 0 && typeof datosTbody[i] === "object" && i === (datosTbody.length - 1)){
        console.log(datosTbody[i] + " Es body");
        auxArrBody.push(datosTbody[i])
        arrBody.push(auxArrBody)
    }
    else
    if (i !== 0 && typeof datosTbody[i-1] === "string") {
        console.log(datosTbody[i] + " Es header");
        arrHeader.push(datosTbody[i])
    }else
    if (i !== 0 && typeof datosTbody[i-1] === "object" && typeof datosTbody[i] === "object") {
        console.log(datosTbody[i] + " Es body");
        auxArrBody.push(datosTbody[i])
    }else
    if (i !== 0 && typeof datosTbody[i] === "object" && typeof datosTbody[i+1] === "object") {
        console.log(datosTbody[i] + " Es body");
        auxArrBody.push(datosTbody[i])
    }else
    if (i !== 0 && typeof datosTbody[i] === "object" && typeof datosTbody[i+1] === "string") {
        console.log(datosTbody[i] + " Es body");
        auxArrBody.push(datosTbody[i])
    }
}

//console.log("lenght body: "+arrBody.length)
//console.log("lenght titulo: "+arrTitulo.length)
//console.log("lenght header: "+arrHeader.length)

//console.log("arrTitulo: "+arrTitulo);
//console.log("arrHeader: "+arrHeader[0]);
//console.log("arrBody: "+arrBody[2]);

arr2 = [[
  'Número de Identificación',
  'Primer Nombre',
  'Segundo Nombre',
  'Primer Apellido',
  'Segundo Apellido',
  'Sexo'
],
[ 'CC 1016109429', 'JUAN', 'SEBASTIAN', 'JARAMILLO', 'SILVA', 'M' ],
[
  'Administradora',
  'Régimen',
  'Fecha Afiliacion',
  'Estado de Afiliación',
  'Tipo de Afiliado',
  'Departamento -> Municipio'
],
[
  'EPS FAMISANAR S.A.S.',
  'Contributivo',
  '01/03/2018',
  'Activo',
  'COTIZANTE',
  'BOGOTA D.C.'
],
[
  'Régimen',
  'Administradora',
  'Fecha de Afiliación',
  'Estado de Afiliación'
],
[
  'PENSIONES: AHORRO INDIVIDUAL',
  'SOCIEDAD ADMINISTRADORA DE FONDOS DE PENSIONES Y CESANTIAS PORVENIR SA',
  '2023-02-12',
  'Inactivo'
],
[
  'Administradora CF',
  'Fecha de Afiliación',
  'Estado de Afiliación',
  'Tipo de Miembro de la Población Cubierta',
  'Tipo de Afiliado',
  'Municipio Labora'
],
[
  'CAJA DE COMPENSACION FAMILIAR COMPENSAR',
  '2023-02-11',
  'Activo',
  'Afiliado',
  'Trabajador afiliado dependiente',
  ''
]]

let T_InfoBasica = "INFORMACIÓN BASICA";
let T_AfiliacionSalud = "AFILIACIÓN A SALUD";
let T_AfiliacionPensiones = "AFILIACIÓN A PENSIONES";
let T_AfiliacionRiesgosLab = "AFILIACIÓN A RIESGOS LABORALES";
let T_AfiliacionCompFam = "AFILIACIÓN A COMPENSACIÓN FAMILIAR";
let T_AfiliacionCesantias = "AFILIACIÓN A CESANTIAS";
let T_Pensionados = "PENSIONADOS";
let T_VinculacionProgAS = "INFORMACIÓN VINCULACIÓN A PROGRAMAS DE ASISTENCIA SOCIAL";

// Organizar titulos datos tabla
let titulosTabla = [].concat(arr2);

for (let i = 0; i < arr2.length; i++) {
    if (arr2[i].includes('Número de Identificación')) {
        titulosTabla.splice(i, 0, T_InfoBasica)
    }
    else if (arr2[i].includes('Departamento -> Municipio')) {
        titulosTabla.splice(i, 0, T_AfiliacionSalud)
    }
    else if (arr2[i][0].includes('Régimen') && arr2[i].length == 4) {
        titulosTabla.splice(i, 0, T_AfiliacionPensiones)
    }
    else if (arr2[i].includes('Actividad Economica') && arr2[i].length == 5) {
        titulosTabla.splice(i, 0, T_AfiliacionRiesgosLab)
    }
    else if (arr2[i].includes('Tipo de Miembro de la Población Cubierta')) {
        titulosTabla.splice(i, 0, T_AfiliacionCompFam)
    }
    else if (arr2[i][0].includes('Régimen') && arr2[i].length == 5) {
        titulosTabla.splice(i, 0, T_AfiliacionCesantias)
    }
  }

  for (const item of titulosTabla) {
    console.log(item)
  }