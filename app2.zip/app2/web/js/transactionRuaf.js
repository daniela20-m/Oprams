const { BooleanOptionalAction } = require("argparse");

const formElement = document.getElementById("saveTransaction"); // Obtener datos de formulario

/*
  Event Listener submit para consultar RUAF
*/
formElement.addEventListener("submit", (event) => {
    event.preventDefault(); // Omitir funcionalidad de redireccionamiento de página
    // Definir parámetros para enviar
    let tipoDoc = document.getElementById("idTipoDoc").value;
    let numDoc = document.getElementById("idNumDoc").value;
    let fechaExp = document.getElementById("idFechaExp").value;
    let fechaExpConvert = convertDateFormat(fechaExp);
    let opcionModulo = 2;
 
    // Crear array Json con parámetros tipoDOc, numDoc, FecgaExp y el número de módulo al que corresponde
    let transaction = {transactionTipoDoc: tipoDoc, transactionNumDoc: numDoc, transactionFechaExp: fechaExpConvert, transactionOpcionModulo: opcionModulo};
    let transactionJson = JSON.stringify(transaction); // Convertir array a Json String

  //Enviar petición por método post sobre el array json al backend al servidor que se ejecuta
    fetch('http://localhost:3000/transaction',{
    method: 'Post',    
    body : transactionJson
    })
    .catch(response => {
      alert("Error de conexión en el servidor, estado: "+response.status)
    })

    // Recargar página actual al cabo de x segundos
    setTimeout(function() {
        location.reload();
      }, 5000);
})

// Enviar petición por método get para recuperar la información del backend e imprimirla en consola
fetch('http://localhost:3000/transaction').then(x => x.json()).then(x => {
    console.log(x); // Imprimir la respuesta en la consola
  })    

  // Función para cambiar el formato de la fecha de expedición (DD/MM/AAAA)
  function convertDateFormat(string) {
    var info = string.split('-').reverse().join('/');
    return info;
}