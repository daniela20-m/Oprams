function renderTableRuaf(consultaRF) {
  // Obtener el contenedor de tablas
  let tablaContainer = document.querySelector("#datatableRuaf");
  tablaContainer.innerHTML = '';

  // Procesar los datos y crear las tablas
  var datosTbody = consultaRF.datosTbody;
  var datosDiv = consultaRF.datosDiv;

  let arrStr = [];
  for (const element of datosTbody) {
    if (typeof element === "string") arrStr.push(element);
  }

  console.log("Arr Str: " + arrStr);

  // Declarar variables para alamacenar cada elemento según corresponda.
  let arrTitulo = [];
  let arrHeader = [];
  let arrBody = [];
  let auxArrBody = [];

  // Llenar los array determinando mediante ciclo y validaciones si corresponde a titulo, header o body.
  for (let i = 0; i < datosTbody.length; i++) {
    if (typeof datosTbody[i] === "string") {
      console.log(datosTbody[i] + " Es Titulo");
      arrTitulo.push(datosTbody[i]);
      if (i !== 0) {
        arrBody.push(auxArrBody);
        auxArrBody = [];
      }
    } else if (
      i !== 0 && typeof datosTbody[i] === "object" && i === datosTbody.length - 1) {
      console.log(datosTbody[i] + " Es body");
      auxArrBody.push(datosTbody[i]);
      arrBody.push(auxArrBody);
    } else if (i !== 0 && typeof datosTbody[i - 1] === "string") {
      console.log(datosTbody[i] + " Es header");
      arrHeader.push(datosTbody[i]);
    } else if (i !== 0 && typeof datosTbody[i - 1] === "object" && typeof datosTbody[i] === "object") {
      console.log(datosTbody[i] + " Es body");
      auxArrBody.push(datosTbody[i]);
    } else if (i !== 0 && typeof datosTbody[i] === "object" && typeof datosTbody[i + 1] === "object") {
      console.log(datosTbody[i] + " Es body");
      auxArrBody.push(datosTbody[i]);
    } else if (i !== 0 && typeof datosTbody[i] === "object" && typeof datosTbody[i + 1] === "string") {
      console.log(datosTbody[i] + " Es body");
      auxArrBody.push(datosTbody[i]);
    }
  }

  //console.log("lenght header: " + arrHeader.length);
  //console.log("Datos header: " + arrHeader);

  // Crear tablas mediante ciclo.
  for (let i = 0; i < arrTitulo.length; i++) {
  //  console.log("contador: " + i);
    let value = crearTabla(arrTitulo[i], arrHeader[i], arrBody[i]);
    tablaContainer.innerHTML += value;
  }

  // Crear tablas DIV mediante ciclo
  for (let j = 0; j < datosDiv.length; j += 2) {
    var tituloDiv = datosDiv[j];
    var contenidoDiv = datosDiv[j + 1];
    let value = crearDivs(tituloDiv, contenidoDiv);
    tablaContainer.innerHTML += value;
  }
}

// Función para crear una tabla
function crearTabla(titulo, header, body) {
  //console.log("llega header " + header);
  var tabla = "";
  tabla +=
    `<div class="datatable-container">
            <div class="header-tools">
            <div class="tools">
                <ul>
                    <li>
                        <button>
                        <i class="material-icons">download</i>
                    </button>
                    </li>
                    <li>
                    <span>` +titulo +`</span>
                    </li>
                </ul>
            </div>
            </div>
            <table class="datatable">
                <thead>
                  <tr>`;
          for (var i = 0; i < header.length; i++) {
            tabla += "<th>" + header[i] + "</th>";
          }
            tabla += "</tr></thead>";
            tabla += "<tbody>";
            for (var i = 0; i < body.length; i++) {
              tabla += "<tr>";
              for (var j = 0; j < body[i].length; j++) {
              tabla += "<td>" + body[i][j] + "</td>";
              }
             tabla += "</tr>";
           }
         tabla += "</tbody>";
         tabla += "</table>";
  //console.log(tabla);
  return tabla;
}

function crearDivs(titulo, contenidoDiv) {
    // Mostrar los divs
    var tabla = "";
    tabla += `<div class="datatable-container">
                  <table class="datatable">
                      <thead>
                      <tr>`;
    tabla += "<th>" + titulo + "</th>";
    tabla += "</tr></thead>";
    tabla += "<tbody>";
    tabla += "<tr>";
    tabla += "<td>" + contenidoDiv + "</td>";
    tabla += "</tr>";
    tabla += "</tbody>";
    tabla += "</table>";
  // console.log(tabla);
  return tabla;
}
