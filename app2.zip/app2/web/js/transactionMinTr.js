const formElement = document.getElementById("saveTransaction"); // Obtener datos de formulario
/*
  Event Listener submit para consultar placa
*/
formElement.addEventListener("submit", (event) => {
    event.preventDefault(); // Omitir funcionalidad de redireccionamiento de página
    // Abrir ventana modal de carga
    var abrirModal = document.getElementById("btnMostrarModal");
    // Oculta la ventana modal cambiando su estilo
    abrirModal.click();
    // Definir parámetros para enviar
    
    // Limpiar texto de los div resultado
    var div1 = document.getElementById('resultadoMinTrans');
    div1.innerHTML = ''
    var div2 = document.getElementById('resultadoSimit');
    div2.innerHTML = ''
    var div3 = document.getElementById('resultadoRuaf')
    div3.innerHTML = ''

    // Obtener parametro(s) de entrada
    // MinTransporte y Simit
    let placa = document.getElementById("idPlaca").value;
    // RUAF
    let tipoDoc = document.getElementById("idTipoDoc").value;
    let numDoc = document.getElementById("idNumDoc").value;
    let fechaExp = document.getElementById("idFechaExp").value;
    let fechaExpConvert = convertDateFormat(fechaExp);

    // Crear array Json con parámetros de placa
    let transaction = {transactionPlaca: placa, transactionTipoDoc: tipoDoc, transactionNumDoc: numDoc, transactionFechaExp: fechaExpConvert};
    let transactionJson = JSON.stringify(transaction); // Convertir array a Json String

    
    //Enviar petición por método post sobre el array json al backend al servidor que se ejecuta
    fetch('http://localhost:3000/transaction',{
    method: 'Post',    
    body : transactionJson
    })
    .catch(response => {
      alert("Error de conexión en el servidor, estado: "+response.status)
      cerrarModal();
    })
  

    let respuestaTransaccion;
    let timeout;
    // Recargar página actual al cabo de x segundos
    getTransaction(); // Llamar función para realizar transacciones método get por primera vez

    /* Función para enviar peticiones por método get constantemente (1seg) verificando si existe un resultado
      - Si no existe resultado, por recursividad se llama a si mismo para iniciar de nuevo el flujo
      - Si existe resultado imprime por consola en el front-end la información obtenida del servidor
    */
    function getTransaction() {
      clearTimeout(timeout); // Limpiar contador
      timeout = setTimeout(function() {
      fetch('http://localhost:3000/transaction')
      .then(x => x.json())
      .then(x => {
        respuestaTransaccion = x["validarTransaccion"];
        if (respuestaTransaccion == 'true') {
          console.log(x);
          cerrarModal();
        }else{
          getTransaction();
        }
        })
        .catch(response => {
          alert("Error de conexión en el servidor, estado: "+response.status)
          cerrarModal();
        })    
      }, 1000);
    }  
    
     // Cerrar ventana modal de carga
    function cerrarModal(){
      var cerrarModal = document.getElementById("btnCerrarModal");
      cerrarModal.click();
    }

    // Función para cambiar el formato de la fecha de expedición (DD/MM/AAAA)
  function convertDateFormat(string) {
    var info = string.split('-').reverse().join('/');
    return info;
}
})  