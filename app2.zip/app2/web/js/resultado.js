/*
Función para obtener el log de consola y replicarlo en los elementos DIV
*/
(function() {
  try {
    var oldLog = console.log;
    var consoleLogDivMT = document.getElementById('resultadoMinTrans');
    var consoleLogDivSM = document.getElementById('resultadoSimit');
    var consoleLogDivRF = document.getElementById('resultadoRuaf');
    var tablaContainerRuaf= document.getElementById('datatableRuaf');
    var tablaContainerSimit= document.getElementById('datatableSimit');
    
    // Obtener el parámetro resultConsultaX del objeto JSON en consola, dependiendo de la cantidad de páginas
    console.log = function(message) {
      var consultaMT = message["resultConsultaMT"];
      var consultaSM = message["resultConsultaSM"];
      var consultaRF = message["resultConsultaRF"];
      tablaContainerRuaf.innerHTML = '';
      tablaContainerSimit.innerHTML = '';

      if (typeof message == 'object') { // Validar si lo que se imprimió por consola es un objeto
        if (typeof consultaSM === 'object'){
          const dt = new RenderTableSimit('#datatableSimit', [
            {
                id: 'bAdd',
                text: 'agregar',
                icon: 'add_circle',
                action: function(){
                    // codigo callback
                    console.log('Agregar un nuevo dato');
                    dt.add(['offline', 'Juan Jaramillo', 'Engineer', 'Siattle', '29', '2020/10/01']);
                }
            },
            {
                id: 'bDelete',
                text: 'eliminar',
                icon: 'delete',
                action: function(){
                    // codigo callback
                    console.log('Acción de eliminar');
                    const elementos = dt.getSelected();
                }
            },
        ]);
        dt.parse(consultaSM); // mapear tabla
        }
        
        if (typeof consultaRF === 'object'){
          renderTableRuaf(consultaRF);
        }
        
        consoleLogDivMT.innerHTML = '';
        consoleLogDivSM.innerHTML = '';
        consoleLogDivRF.innerHTML = '';
        consoleLogDivMT.innerHTML += (JSON && JSON.stringify ? JSON.stringify(consultaMT) : consultaMT) + '<br />';
        consoleLogDivSM.innerHTML += (JSON && JSON.stringify ? JSON.stringify(consultaSM) : consultaSM) + '<br />';
        consoleLogDivRF.innerHTML += (JSON && JSON.stringify ? JSON.stringify(consultaRF) : consultaRF) + '<br />';
      } else {
        //consoleLogDiv.innerHTML += message + '<br />';
        consoleLogDivMT.innerHTML += (JSON && JSON.stringify ? JSON.stringify(consultaMT) : consultaMT)
        consoleLogDivSM.innerHTML += (JSON && JSON.stringify ? JSON.stringify(consultaSM) : consultaSM)
        consoleLogDivRF.innerHTML += (JSON && JSON.stringify ? JSON.stringify(consultaRF) : consultaRF);
      }
      oldLog.apply(console, arguments);
    };
  } catch (error) {
    console.log("Error:"+ error);
  }
  })();